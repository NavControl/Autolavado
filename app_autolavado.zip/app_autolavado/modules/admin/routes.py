from flask import render_template, redirect, url_for, request, flash, session
from . import admin_bp

@admin_bp.route('/')
def admin_index():
    return redirect(url_for('admin.inicio'))

@admin_bp.route('/inicio')
def inicio():
    return render_template('admin/dashboard.html')